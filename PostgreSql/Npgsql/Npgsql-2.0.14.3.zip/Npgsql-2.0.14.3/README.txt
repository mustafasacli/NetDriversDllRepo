
Npgsql - .Net Data Provider for PostgreSQL



WHAT'S IT?
==========
    
    Npgsql is a .Net Data Provider for PostgreSQL. It allows you to connect to PostgreSQL server
in .Net.


HISTORY
=======
    
    Check RELEASENOTES.txt file for a comprehensive list of details about Npgsql history.
    

COMPILING
===========
run 'nant' from src


RUNNING TESTSUITE
==========
run 'nant tests' from src


DEVELOPERS
==========
    
    We have the following developers who work or have worked with Npgsql since its beginning, in no particular order:
    
    Brar Piening
    Francisco Figueiredo Jr.
    Ben Clewett
    Daniel Morgan
    Dave Page
    Ulrich Sprick
    Glen Parker
    Josh Cooley
    Jon Asher
    Chris Morgan
    Thilo Utke
    Hiroshi Saito

    
CONTACT INFO
============
    
    Web:
    All info related to Npgsql can be found in its homepage:
    http://www.npgsql.org
    http://npgsql.projects.postgresql.org
    
    

    

