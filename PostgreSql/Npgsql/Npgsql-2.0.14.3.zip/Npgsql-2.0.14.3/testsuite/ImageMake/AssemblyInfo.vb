Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices


<Assembly: AssemblyTitle("")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("Npgsql Development Team")> 
<Assembly: AssemblyProduct("ImageMake")> 
<Assembly: AssemblyCopyright("2002-2006 (C) Npgsql Development Team")> 
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>

<Assembly:  AssemblyVersion("1.0.*")>


