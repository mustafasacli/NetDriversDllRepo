This can be used by Microsoft Visual Basic.NET 2003.

This tool can make the quality of a registration picture unification.
For example, probably, there are various focuses, such as a photograph 
of  face, and a size. They can decide the required range with paint software.
And it paste with this tool via a clip board. The rest makes a picture frame 
decide by operation of expansion and reduction by mouse operation.
They are splendidly managed by PostgreSQL.!!

Usage.

1. Connect to a database and create the required table using
InitialSetting->CreateTable or (if already created) use File->Login to
connect to the database.
2. Copy an image of the subject to the clipboard
3. Paste the image into the tool using the 'Paste' button
4. Adjust the size using the right and left mouse buttons
5. Save the image to the database using the 'Save' button
6. Retrieve previously saved records by entering the ID and pressing the
Query button


