HA-JDBC: High-Availability JDBC
=======
http://ha-jdbc.github.com
