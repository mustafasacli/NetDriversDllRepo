

package com.opensourceconnections.msjdbcproxy;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;

public class ResultSetProxy implements ResultSet
{
    protected final Statement _statement;
    protected final ResultSet _resultSet;
    protected final ColumnSet _columns;

    public ResultSetProxy(Statement statement, ResultSet resultSet) throws SQLException
    {
        _statement = statement;
        _resultSet = resultSet;
        _columns = new ColumnSet(_resultSet);
    }

    public boolean next() throws SQLException
    {
        return _columns.load(_resultSet.next());
    }

    public void close() throws SQLException
    {
        _resultSet.close();
    }

    public boolean wasNull() throws SQLException
    {
        return _columns.wasNull();
    }

    public String getString(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getString();
    }

    public boolean getBoolean(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getBoolean();
    }

    public byte getByte(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getByte();
    }

    public short getShort(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getShort();
    }

    public int getInt(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getInt();
    }

    public long getLong(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getLong();
    }

    public float getFloat(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getFloat();
    }

    public double getDouble(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getDouble();
    }

    public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException
    {
        return _columns.getColumn(columnIndex).getBigDecimal(scale);
    }

    public byte[] getBytes(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getBytes();
    }

    public Date getDate(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getDate();
    }

    public Time getTime(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getTime();
    }

    public Timestamp getTimestamp(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getTimestamp();
    }

    public InputStream getAsciiStream(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getAsciiStream();
    }

    public InputStream getUnicodeStream(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getUnicodeStream();
    }

    public InputStream getBinaryStream(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getBinaryStream();
    }

    public String getString(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getString();
    }

    public boolean getBoolean(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getBoolean();
    }

    public byte getByte(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getByte();
    }

    public short getShort(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getShort();
    }

    public int getInt(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getInt();
    }

    public long getLong(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getLong();
    }

    public float getFloat(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getFloat();
    }

    public double getDouble(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getDouble();
    }

    public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException
    {
        return _columns.getColumn(columnName).getBigDecimal(scale);
    }

    public byte[] getBytes(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getBytes();
    }

    public Date getDate(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getDate();
    }

    public Time getTime(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getTime();
    }

    public Timestamp getTimestamp(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getTimestamp();
    }

    public InputStream getAsciiStream(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getAsciiStream();
    }

    public InputStream getUnicodeStream(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getUnicodeStream();
    }

    public InputStream getBinaryStream(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getBinaryStream();
    }

    public SQLWarning getWarnings() throws SQLException
    {
        return _resultSet.getWarnings();
    }

    public void clearWarnings() throws SQLException
    {
        _resultSet.clearWarnings();
    }

    public String getCursorName() throws SQLException
    {
        return _resultSet.getCursorName();
    }

    public ResultSetMetaData getMetaData() throws SQLException
    {
        return _resultSet.getMetaData();
    }

    public Object getObject(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getObject();
    }

    public Object getObject(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getObject();
    }

    public int findColumn(String columnName) throws SQLException
    {
        return _columns.findColumn(columnName);
    }

    public Reader getCharacterStream(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getCharacterStream();
    }

    public Reader getCharacterStream(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getCharacterStream();
    }

    public BigDecimal getBigDecimal(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getBigDecimal();
    }

    public BigDecimal getBigDecimal(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getBigDecimal();
    }

    public boolean isBeforeFirst() throws SQLException
    {
        return _resultSet.isBeforeFirst();
    }

    public boolean isAfterLast() throws SQLException
    {
        return _resultSet.isAfterLast();
    }

    public boolean isFirst() throws SQLException
    {
        return _resultSet.isFirst();
    }

    public boolean isLast() throws SQLException
    {
        return _resultSet.isLast();
    }

    public void beforeFirst() throws SQLException
    {
        _resultSet.beforeFirst();
    }

    public void afterLast() throws SQLException
    {
        _resultSet.afterLast();
    }

    public boolean first() throws SQLException
    {
        return _columns.load(_resultSet.first());
    }

    public boolean last() throws SQLException
    {
        return _columns.load(_resultSet.last());
    }

    public int getRow() throws SQLException
    {
        return _resultSet.getRow();
    }

    public boolean absolute(int row) throws SQLException
    {
        return _columns.load(_resultSet.absolute(row));
    }

    public boolean relative(int rows) throws SQLException
    {
        return _columns.load(_resultSet.relative(rows));
    }

    public boolean previous() throws SQLException
    {
        return _columns.load(_resultSet.previous());
    }

    public void setFetchDirection(int direction) throws SQLException
    {
        _resultSet.setFetchDirection(direction);
    }

    public int getFetchDirection() throws SQLException
    {
        return _resultSet.getFetchDirection();
    }

    public void setFetchSize(int rows) throws SQLException
    {
        _resultSet.setFetchSize(rows);
    }

    public int getFetchSize() throws SQLException
    {
        return _resultSet.getFetchSize();
    }

    public int getType() throws SQLException
    {
        return _resultSet.getType();
    }

    public int getConcurrency() throws SQLException
    {
        return _resultSet.getConcurrency();
    }

    public boolean rowUpdated() throws SQLException
    {
        return _resultSet.rowUpdated();
    }

    public boolean rowInserted() throws SQLException
    {
        return _resultSet.rowInserted();
    }

    public boolean rowDeleted() throws SQLException
    {
        return _resultSet.rowDeleted();
    }

    public void updateNull(int columnIndex) throws SQLException
    {
        _resultSet.updateNull(columnIndex);
    }

    public void updateBoolean(int columnIndex, boolean x) throws SQLException
    {
        _resultSet.updateBoolean(columnIndex, x);
    }

    public void updateByte(int columnIndex, byte x) throws SQLException
    {
        _resultSet.updateByte(columnIndex, x);
    }

    public void updateShort(int columnIndex, short x) throws SQLException
    {
        _resultSet.updateShort(columnIndex, x);
    }

    public void updateInt(int columnIndex, int x) throws SQLException
    {
        _resultSet.updateInt(columnIndex, x);
    }

    public void updateLong(int columnIndex, long x) throws SQLException
    {
        _resultSet.updateLong(columnIndex, x);
    }

    public void updateFloat(int columnIndex, float x) throws SQLException
    {
        _resultSet.updateFloat(columnIndex, x);
    }

    public void updateDouble(int columnIndex, double x) throws SQLException
    {
        _resultSet.updateDouble(columnIndex, x);
    }

    public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException
    {
        _resultSet.updateBigDecimal(columnIndex, x);
    }

    public void updateString(int columnIndex, String x) throws SQLException
    {
        _resultSet.updateString(columnIndex, x);
    }

    public void updateBytes(int columnIndex, byte x[]) throws SQLException
    {
        _resultSet.updateBytes(columnIndex, x);
    }

    public void updateDate(int columnIndex, Date x) throws SQLException
    {
        _resultSet.updateDate(columnIndex, x);
    }

    public void updateTime(int columnIndex, Time x) throws SQLException
    {
        _resultSet.updateTime(columnIndex, x);
    }

    public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException
    {
        _resultSet.updateTimestamp(columnIndex, x);
    }

    public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException
    {
        _resultSet.updateAsciiStream(columnIndex, x, length);
    }

    public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException
    {
        _resultSet.updateBinaryStream(columnIndex, x, length);
    }

    public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException
    {
        _resultSet.updateCharacterStream(columnIndex, x, length);
    }

    public void updateObject(int columnIndex, Object x, int scale) throws SQLException
    {
        _resultSet.updateObject(columnIndex, x, scale);
    }

    public void updateObject(int columnIndex, Object x) throws SQLException
    {
        _resultSet.updateObject(columnIndex, x);
    }

    public void updateNull(String columnName) throws SQLException
    {
        _resultSet.updateNull(columnName);
    }

    public void updateBoolean(String columnName, boolean x) throws SQLException
    {
        _resultSet.updateBoolean(columnName, x);
    }

    public void updateByte(String columnName, byte x) throws SQLException
    {
        _resultSet.updateByte(columnName, x);
    }

    public void updateShort(String columnName, short x) throws SQLException
    {
        _resultSet.updateShort(columnName, x);
    }

    public void updateInt(String columnName, int x) throws SQLException
    {
        _resultSet.updateInt(columnName, x);
    }

    public void updateLong(String columnName, long x) throws SQLException
    {
        _resultSet.updateLong(columnName, x);
    }

    public void updateFloat(String columnName, float x) throws SQLException
    {
        _resultSet.updateFloat(columnName, x);
    }

    public void updateDouble(String columnName, double x) throws SQLException
    {
        _resultSet.updateDouble(columnName, x);
    }

    public void updateBigDecimal(String columnName, BigDecimal x) throws SQLException
    {
        _resultSet.updateBigDecimal(columnName, x);
    }

    public void updateString(String columnName, String x) throws SQLException
    {
        _resultSet.updateString(columnName, x);
    }

    public void updateBytes(String columnName, byte x[]) throws SQLException
    {
        _resultSet.updateBytes(columnName, x);
    }

    public void updateDate(String columnName, Date x) throws SQLException
    {
        _resultSet.updateDate(columnName, x);
    }

    public void updateTime(String columnName, Time x) throws SQLException
    {
        _resultSet.updateTime(columnName, x);
    }

    public void updateTimestamp(String columnName, Timestamp x) throws SQLException
    {
        _resultSet.updateTimestamp(columnName, x);
    }

    public void updateAsciiStream(String columnName, InputStream x, int length) throws SQLException
    {
        _resultSet.updateAsciiStream(columnName, x, length);
    }

    public void updateBinaryStream(String columnName, InputStream x, int length) throws SQLException
    {
        _resultSet.updateBinaryStream(columnName, x, length);
    }

    public void updateCharacterStream(String columnName, Reader reader, int length) throws SQLException
    {
        _resultSet.updateCharacterStream(columnName, reader, length);
    }

    public void updateObject(String columnName, Object x, int scale) throws SQLException
    {
        _resultSet.updateObject(columnName, x, scale);
    }

    public void updateObject(String columnName, Object x) throws SQLException
    {
        _resultSet.updateObject(columnName, x);
    }

    public void insertRow() throws SQLException
    {
        _resultSet.insertRow();
    }

    public void updateRow() throws SQLException
    {
        _resultSet.updateRow();
    }

    public void deleteRow() throws SQLException
    {
        _resultSet.deleteRow();
    }

    public void refreshRow() throws SQLException
    {
        _resultSet.refreshRow();
    }

    public void cancelRowUpdates() throws SQLException
    {
        _resultSet.cancelRowUpdates();
    }

    public void moveToInsertRow() throws SQLException
    {
        _resultSet.moveToInsertRow();
    }

    public void moveToCurrentRow() throws SQLException
    {
        _resultSet.moveToCurrentRow();
    }

    public Statement getStatement() throws SQLException
    {
        return _statement;
    }

    public Object getObject(int i, Map map) throws SQLException
    {
        return _columns.getColumn(i).getObject(map);
    }

    public Ref getRef(int i) throws SQLException
    {
        return _columns.getColumn(i).getRef();
    }

    public Blob getBlob(int i) throws SQLException
    {
        return _columns.getColumn(i).getBlob();
    }

    public Clob getClob(int i) throws SQLException
    {
        return _columns.getColumn(i).getClob();
    }

    public Array getArray(int i) throws SQLException
    {
        return _columns.getColumn(i).getArray();
    }

    public Object getObject(String colName, Map map) throws SQLException
    {
        return _columns.getColumn(colName).getObject(map);
    }

    public Ref getRef(String colName) throws SQLException
    {
        return _columns.getColumn(colName).getRef();
    }

    public Blob getBlob(String colName) throws SQLException
    {
        return _columns.getColumn(colName).getBlob();
    }

    public Clob getClob(String colName) throws SQLException
    {
        return _columns.getColumn(colName).getClob();
    }

    public Array getArray(String colName) throws SQLException
    {
        return _columns.getColumn(colName).getArray();
    }

    public Date getDate(int columnIndex, Calendar cal) throws SQLException
    {
        return _columns.getColumn(columnIndex).getDate(cal);
    }

    public Date getDate(String columnName, Calendar cal) throws SQLException
    {
        return _columns.getColumn(columnName).getDate(cal);
    }

    public Time getTime(int columnIndex, Calendar cal) throws SQLException
    {
        return _columns.getColumn(columnIndex).getTime(cal);
    }

    public Time getTime(String columnName, Calendar cal) throws SQLException
    {
        return _columns.getColumn(columnName).getTime(cal);
    }

    public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException
    {
        return _columns.getColumn(columnIndex).getTimestamp(cal);
    }

    public Timestamp getTimestamp(String columnName, Calendar cal) throws SQLException
    {
        return _columns.getColumn(columnName).getTimestamp(cal);
    }

    public URL getURL(int columnIndex) throws SQLException
    {
        return _columns.getColumn(columnIndex).getURL();
    }

    public URL getURL(String columnName) throws SQLException
    {
        return _columns.getColumn(columnName).getURL();
    }

    public void updateRef(int columnIndex, Ref x) throws SQLException
    {
        _resultSet.updateRef(columnIndex, x);
    }

    public void updateRef(String columnName, Ref x) throws SQLException
    {
        _resultSet.updateRef(columnName, x);
    }

    public void updateBlob(int columnIndex, Blob x) throws SQLException
    {
        _resultSet.updateBlob(columnIndex, x);
    }

    public void updateBlob(String columnName, Blob x) throws SQLException
    {
        _resultSet.updateBlob(columnName, x);
    }

    public void updateClob(int columnIndex, Clob x) throws SQLException
    {
        _resultSet.updateClob(columnIndex, x);
    }

    public void updateClob(String columnName, Clob x) throws SQLException
    {
        _resultSet.updateClob(columnName, x);
    }

    public void updateArray(int columnIndex, Array x) throws SQLException
    {
        _resultSet.updateArray(columnIndex, x);
    }

    public void updateArray(String columnName, Array x) throws SQLException
    {
        _resultSet.updateArray(columnName, x);
    }
}