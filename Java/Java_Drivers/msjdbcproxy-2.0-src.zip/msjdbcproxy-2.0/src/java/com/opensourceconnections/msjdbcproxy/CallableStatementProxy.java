

package com.opensourceconnections.msjdbcproxy;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Date;
import java.sql.Ref;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;

public class CallableStatementProxy extends PreparedStatementProxy implements CallableStatement
{
    public CallableStatementProxy(ConnectionProxy connection, CallableStatement statement)
    {
        super(connection, statement);
    }

    public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException
    {
        ((CallableStatement)_statement).registerOutParameter(parameterIndex, sqlType);
    }

    public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException
    {
        ((CallableStatement)_statement).registerOutParameter(parameterIndex, sqlType, scale);
    }

    public boolean wasNull() throws SQLException
    {
        return ((CallableStatement)_statement).wasNull();
    }

    public String getString(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getString(parameterIndex);
    }

    public boolean getBoolean(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getBoolean(parameterIndex);
    }

    public byte getByte(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getByte(parameterIndex);
    }

    public short getShort(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getShort(parameterIndex);
    }

    public int getInt(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getInt(parameterIndex);
    }

    public long getLong(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getLong(parameterIndex);
    }

    public float getFloat(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getFloat(parameterIndex);
    }

    public double getDouble(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getDouble(parameterIndex);
    }

    public BigDecimal getBigDecimal(int parameterIndex, int scale) throws SQLException
    {
        return ((CallableStatement)_statement).getBigDecimal(parameterIndex, scale);
    }

    public byte[] getBytes(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getBytes(parameterIndex);
    }

    public Date getDate(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getDate(parameterIndex);
    }

    public Time getTime(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getTime(parameterIndex);
    }

    public Timestamp getTimestamp(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getTimestamp(parameterIndex);
    }

    public Object getObject(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getObject(parameterIndex);
    }

    public BigDecimal getBigDecimal(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getBigDecimal(parameterIndex);
    }

    public Object getObject(int i, Map map) throws SQLException
    {
        return ((CallableStatement)_statement).getObject(i, map);
    }

    public Ref getRef(int i) throws SQLException
    {
        return ((CallableStatement)_statement).getRef(i);
    }

    public Blob getBlob(int i) throws SQLException
    {
        return ((CallableStatement)_statement).getBlob(i);
    }

    public Clob getClob(int i) throws SQLException
    {
        return ((CallableStatement)_statement).getClob(i);
    }

    public Array getArray(int i) throws SQLException
    {
        return ((CallableStatement)_statement).getArray(i);
    }

    public Date getDate(int parameterIndex, Calendar cal) throws SQLException
    {
        return ((CallableStatement)_statement).getDate(parameterIndex, cal);
    }

    public Time getTime(int parameterIndex, Calendar cal) throws SQLException
    {
        return ((CallableStatement)_statement).getTime(parameterIndex, cal);
    }

    public Timestamp getTimestamp(int parameterIndex, Calendar cal) throws SQLException
    {
        return ((CallableStatement)_statement).getTimestamp(parameterIndex, cal);
    }

    public void registerOutParameter(int paramIndex, int sqlType, String typeName) throws SQLException
    {
        ((CallableStatement)_statement).registerOutParameter(paramIndex, sqlType, typeName);
    }

    public void registerOutParameter(String parameterName, int sqlType) throws SQLException
    {
        ((CallableStatement)_statement).registerOutParameter(parameterName, sqlType);
    }

    public void registerOutParameter(String parameterName, int sqlType, int scale) throws SQLException
    {
        ((CallableStatement)_statement).registerOutParameter(parameterName, sqlType, scale);
    }

    public void registerOutParameter(String parameterName, int sqlType, String typeName) throws SQLException
    {
        ((CallableStatement)_statement).registerOutParameter(parameterName, sqlType, typeName);
    }

    public URL getURL(int parameterIndex) throws SQLException
    {
        return ((CallableStatement)_statement).getURL(parameterIndex);
    }

    public void setURL(String parameterName, URL val) throws SQLException
    {
        ((CallableStatement)_statement).setURL(parameterName, val);
    }

    public void setNull(String parameterName, int sqlType) throws SQLException
    {
        ((CallableStatement)_statement).setNull(parameterName, sqlType);
    }

    public void setBoolean(String parameterName, boolean x) throws SQLException
    {
        ((CallableStatement)_statement).setBoolean(parameterName, x);
    }

    public void setByte(String parameterName, byte x) throws SQLException
    {
        ((CallableStatement)_statement).setByte(parameterName, x);
    }

    public void setShort(String parameterName, short x) throws SQLException
    {
        ((CallableStatement)_statement).setShort(parameterName, x);
    }

    public void setInt(String parameterName, int x) throws SQLException
    {
        ((CallableStatement)_statement).setInt(parameterName, x);
    }

    public void setLong(String parameterName, long x) throws SQLException
    {
        ((CallableStatement)_statement).setLong(parameterName, x);
    }

    public void setFloat(String parameterName, float x) throws SQLException
    {
        ((CallableStatement)_statement).setFloat(parameterName, x);
    }

    public void setDouble(String parameterName, double x) throws SQLException
    {
        ((CallableStatement)_statement).setDouble(parameterName, x);
    }

    public void setBigDecimal(String parameterName, BigDecimal x) throws SQLException
    {
        ((CallableStatement)_statement).setBigDecimal(parameterName, x);
    }

    public void setString(String parameterName, String x) throws SQLException
    {
        ((CallableStatement)_statement).setString(parameterName, x);
    }

    public void setBytes(String parameterName, byte x[]) throws SQLException
    {
        ((CallableStatement)_statement).setBytes(parameterName, x);
    }

    public void setDate(String parameterName, Date x) throws SQLException
    {
        ((CallableStatement)_statement).setDate(parameterName, x);
    }

    public void setTime(String parameterName, Time x) throws SQLException
    {
        ((CallableStatement)_statement).setTime(parameterName, x);
    }

    public void setTimestamp(String parameterName, Timestamp x) throws SQLException
    {
        ((CallableStatement)_statement).setTimestamp(parameterName, x);
    }

    public void setAsciiStream(String parameterName, InputStream x, int length) throws SQLException
    {
        ((CallableStatement)_statement).setAsciiStream(parameterName, x, length);
    }

    public void setBinaryStream(String parameterName, InputStream x, int length) throws SQLException
    {
        ((CallableStatement)_statement).setBinaryStream(parameterName, x, length);
    }

    public void setObject(String parameterName, Object x, int targetSqlType, int scale) throws SQLException
    {
        ((CallableStatement)_statement).setObject(parameterName, x, targetSqlType, scale);
    }

    public void setObject(String parameterName, Object x, int targetSqlType) throws SQLException
    {
        ((CallableStatement)_statement).setObject(parameterName, x, targetSqlType);
    }

    public void setObject(String parameterName, Object x) throws SQLException
    {
        ((CallableStatement)_statement).setObject(parameterName, x);
    }

    public void setCharacterStream(String parameterName, Reader reader, int length) throws SQLException
    {
        ((CallableStatement)_statement).setCharacterStream(parameterName, reader, length);
    }

    public void setDate(String parameterName, Date x, Calendar cal) throws SQLException
    {
        ((CallableStatement)_statement).setDate(parameterName, x, cal);
    }

    public void setTime(String parameterName, Time x, Calendar cal) throws SQLException
    {
        ((CallableStatement)_statement).setTime(parameterName, x, cal);
    }

    public void setTimestamp(String parameterName, Timestamp x, Calendar cal) throws SQLException
    {
        ((CallableStatement)_statement).setTimestamp(parameterName, x, cal);
    }

    public void setNull(String parameterName, int sqlType, String typeName) throws SQLException
    {
        ((CallableStatement)_statement).setNull(parameterName, sqlType, typeName);
    }

    public String getString(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getString(parameterName);
    }

    public boolean getBoolean(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getBoolean(parameterName);
    }

    public byte getByte(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getByte(parameterName);
    }

    public short getShort(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getShort(parameterName);
    }

    public int getInt(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getInt(parameterName);
    }

    public long getLong(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getLong(parameterName);
    }

    public float getFloat(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getFloat(parameterName);
    }

    public double getDouble(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getDouble(parameterName);
    }

    public byte[] getBytes(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getBytes(parameterName);
    }

    public Date getDate(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getDate(parameterName);
    }

    public Time getTime(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getTime(parameterName);
    }

    public Timestamp getTimestamp(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getTimestamp(parameterName);
    }

    public Object getObject(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getObject(parameterName);
    }

    public BigDecimal getBigDecimal(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getBigDecimal(parameterName);
    }

    public Object getObject(String parameterName, Map map) throws SQLException
    {
        return ((CallableStatement)_statement).getObject(parameterName);
    }

    public Ref getRef(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getRef(parameterName);
    }

    public Blob getBlob(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getBlob(parameterName);
    }

    public Clob getClob(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getClob(parameterName);
    }

    public Array getArray(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getArray(parameterName);
    }

    public Date getDate(String parameterName, Calendar cal) throws SQLException
    {
        return ((CallableStatement)_statement).getDate(parameterName, cal);
    }

    public Time getTime(String parameterName, Calendar cal) throws SQLException
    {
        return ((CallableStatement)_statement).getTime(parameterName, cal);
    }

    public Timestamp getTimestamp(String parameterName, Calendar cal) throws SQLException
    {
        return ((CallableStatement)_statement).getTimestamp(parameterName, cal);
    }

    public URL getURL(String parameterName) throws SQLException
    {
        return ((CallableStatement)_statement).getURL(parameterName);
    }
}