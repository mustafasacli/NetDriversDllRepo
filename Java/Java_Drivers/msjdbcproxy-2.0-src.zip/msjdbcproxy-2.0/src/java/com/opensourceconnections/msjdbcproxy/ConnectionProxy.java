

package com.opensourceconnections.msjdbcproxy;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.Map;

public class ConnectionProxy implements Connection
{
    protected final Connection _connection;

    public ConnectionProxy(Connection connection)
    {
        _connection = connection;
    }

    public Statement createStatement() throws SQLException
    {
        return new StatementProxy(this, _connection.createStatement());
    }

    public PreparedStatement prepareStatement(String sql) throws SQLException
    {
        return new PreparedStatementProxy(this, _connection.prepareStatement(sql));
    }

    public CallableStatement prepareCall(String sql) throws SQLException
    {
        return new CallableStatementProxy(this, _connection.prepareCall(sql));
    }

    public String nativeSQL(String sql) throws SQLException
    {
        return _connection.nativeSQL(sql);
    }

    public void setAutoCommit(boolean autoCommit) throws SQLException
    {
        _connection.setAutoCommit(autoCommit);
    }

    public boolean getAutoCommit() throws SQLException
    {
        return _connection.getAutoCommit();
    }

    public void commit() throws SQLException
    {
        _connection.commit();
    }

    public void rollback() throws SQLException
    {
        _connection.rollback();
    }

    public void close() throws SQLException
    {
        _connection.close();
    }

    public boolean isClosed() throws SQLException
    {
        return _connection.isClosed();
    }

    public DatabaseMetaData getMetaData() throws SQLException
    {
        return _connection.getMetaData();
    }

    public void setReadOnly(boolean readOnly) throws SQLException
    {
        _connection.setReadOnly(readOnly);
    }

    public boolean isReadOnly() throws SQLException
    {
        return _connection.isReadOnly();
    }

    public void setCatalog(String catalog) throws SQLException
    {
        _connection.setCatalog(catalog);
    }

    public String getCatalog() throws SQLException
    {
        return _connection.getCatalog();
    }

    public void setTransactionIsolation(int level) throws SQLException
    {
        _connection.setTransactionIsolation(level);
    }

    public int getTransactionIsolation() throws SQLException
    {
        return _connection.getTransactionIsolation();
    }

    public SQLWarning getWarnings() throws SQLException
    {
        return _connection.getWarnings();
    }

    public void clearWarnings() throws SQLException
    {
        _connection.clearWarnings();
    }

    public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException
    {
        return new StatementProxy(this, _connection.createStatement(resultSetType, resultSetConcurrency));
    }

    public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException
    {
        return new PreparedStatementProxy(this, _connection.prepareStatement(sql, resultSetType, resultSetConcurrency));
    }

    public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException
    {
        return new CallableStatementProxy(this, _connection.prepareCall(sql, resultSetType, resultSetConcurrency));
    }

    public Map getTypeMap() throws SQLException
    {
        return _connection.getTypeMap();
    }

    public void setTypeMap(Map map) throws SQLException
    {
        _connection.setTypeMap(map);
    }

    public void setHoldability(int holdability) throws SQLException
    {
        _connection.setHoldability(holdability);
    }

    public int getHoldability() throws SQLException
    {
        return _connection.getHoldability();
    }

    public Savepoint setSavepoint() throws SQLException
    {
        return _connection.setSavepoint();
    }

    public Savepoint setSavepoint(String name) throws SQLException
    {
        return _connection.setSavepoint(name);
    }

    public void rollback(Savepoint savepoint) throws SQLException
    {
        _connection.rollback(savepoint);
    }

    public void releaseSavepoint(Savepoint savepoint) throws SQLException
    {
        _connection.releaseSavepoint(savepoint);
    }

    public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
    {
        return new StatementProxy(this, _connection.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability));
    }

    public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
    {
        return new PreparedStatementProxy(this, _connection.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
    }

    public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
    {
        return new CallableStatementProxy(this, _connection.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
    }

    public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException
    {
        return new PreparedStatementProxy(this, _connection.prepareStatement(sql, autoGeneratedKeys));
    }

    public PreparedStatement prepareStatement(String sql, int columnIndexes[]) throws SQLException
    {
        return new PreparedStatementProxy(this, _connection.prepareStatement(sql, columnIndexes));
    }

    public PreparedStatement prepareStatement(String sql, String columnNames[]) throws SQLException
    {
        return new PreparedStatementProxy(this, _connection.prepareStatement(sql, columnNames));
    }
}