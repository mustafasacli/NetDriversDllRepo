

package com.opensourceconnections.msjdbcproxy;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Calendar;
import java.util.Map;

import org.hibernate.Hibernate;


public class ColumnSet
{
    private final ResultSet _resultSet;
    private final Column[] _columns;
    private boolean _null;

    public ColumnSet(ResultSet resultSet) throws SQLException
    {
        _resultSet = resultSet;

        ResultSetMetaData meta = _resultSet.getMetaData();

        int count = meta.getColumnCount();

        _columns = new Column[count];

        for (int index = 0; index < count; index++) _columns[index] = new Column(meta, index + 1);
    }

    public final int findColumn(String name) throws SQLException
    {
        for (int index = 0; index < _columns.length; index++)
            if (_columns[index]._name.equalsIgnoreCase(name)) return index + 1;

        throw new SQLException("Column " + name + " not found");
    }

    public final Column getColumn(int index)
    {
        return _columns[index - 1];
    }

    public final Column getColumn(String name) throws SQLException
    {
        return getColumn(findColumn(name));
    }

    public final boolean wasNull()
    {
        return _null;
    }

    public final boolean load(boolean valid) throws SQLException
    {
        if (valid) for (int index = 0; index < _columns.length; index++) _columns[index].load();

        return valid;
    }

    class Column
    {
        private final int _index;
        private final String _name;
        private final int _type;
        private Object _value;

        public Column(ResultSetMetaData meta, int index) throws SQLException
        {
            _index = index;
            _name = meta.getColumnName(index);
            _type = meta.getColumnType(index);
        }

        public void load() throws SQLException
        {
            switch (_type) {
            case Types.ARRAY:
                _value = _resultSet.getArray(_index);
                break;
            case Types.BINARY:
            case Types.VARBINARY:
            case Types.BLOB:
                if (true){                
                    _value = _resultSet.getBlob(_index);
                }
                else{
                    _value = _resultSet.getBytes(_index);
                }
                break;
            case Types.LONGVARBINARY:
            	 _value = _resultSet.getBytes(_index);
            	 break;                
            case Types.CLOB:
                _value = _resultSet.getClob(_index);
                break;
            case Types.REF:
                _value = _resultSet.getRef(_index);
                break;
            default:
                _value = _resultSet.getObject(_index);
            }

            if (_resultSet.wasNull()) _value = null;
        }

        public String getString() throws SQLException
        {
            if (_null = (_value == null)) return null;

            if (_value instanceof String) return (String)_value;

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public boolean getBoolean() throws SQLException
        {
            if (_null = (_value == null)) return false;

            if (_value instanceof Boolean) return ((Boolean)_value).booleanValue();
            if (_value instanceof Number) return ((Number)_value).intValue() != 0;

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public byte getByte() throws SQLException
        {
            if (_null = (_value == null)) return 0;

            if (_value instanceof Number) return ((Number)_value).byteValue();

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public short getShort() throws SQLException
        {
            if (_null = (_value == null)) return 0;

            if (_value instanceof Number) return ((Number)_value).shortValue();

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public int getInt() throws SQLException
        {
            if (_null = (_value == null)) return 0;

            if (_value instanceof Number) return ((Number)_value).intValue();

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public long getLong() throws SQLException
        {
            if (_null = (_value == null)) return 0;

            if (_value instanceof Number) return ((Number)_value).longValue();

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public float getFloat() throws SQLException
        {
            if (_null = (_value == null)) return 0;

            if (_value instanceof Number) return ((Number)_value).floatValue();

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public double getDouble() throws SQLException
        {
            if (_null = (_value == null)) return 0;

            if (_value instanceof Number) return ((Number)_value).doubleValue();

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public BigDecimal getBigDecimal(int scale) throws SQLException
        {
            throw new SQLException("ResultSet.getBigDecimal(int) not supported");
        }

        public BigDecimal getBigDecimal() throws SQLException
        {
            if (_null = (_value == null)) return null;

            if (_value instanceof BigDecimal) return (BigDecimal)_value;

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public byte[] getBytes() throws SQLException
        {
            if (_null = (_value == null)) return null;

            if (_value instanceof byte[]) return (byte[])_value;

            if (_value instanceof Blob) {
                Blob blob = (Blob)_value;

                return blob.getBytes(1, (int)blob.length());
            }

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public Date getDate() throws SQLException
        {
            if (_null = (_value == null)) return null;

            if (_value instanceof Date) {
                return (Date)_value;
            }
            if (_value instanceof Timestamp) {
                return new Date(((Timestamp)_value).getTime()); 
            }
            

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public Date getDate(Calendar cal) throws SQLException
        {
            throw new SQLException("ResultSet.getDate(Calendar) not supported");
        }

        public Time getTime() throws SQLException
        {
            if (_null = (_value == null)) return null;

            if (_value instanceof Time) return (Time)_value;

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public Time getTime(Calendar cal) throws SQLException
        {
            throw new SQLException("ResultSet.getTime(Calendar) not supported");
        }

        public Timestamp getTimestamp() throws SQLException
        {
            if (_null = (_value == null)) return null;

            if (_value instanceof Timestamp) return (Timestamp)_value;

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public Timestamp getTimestamp(Calendar cal) throws SQLException
        {
            throw new SQLException("ResultSet.getTimestamp(Calendar) not supported");
        }

        public URL getURL() throws SQLException
        {
            if (_null = (_value == null)) return null;

            if (_value instanceof URL) return (URL)_value;

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public Object getObject()
        {
            if (_null = (_value == null)) return null;

            return _value;
        }

        public Object getObject(Map map) throws SQLException
        {
            throw new SQLException("ResultSet.getObject(Map) not supported");
        }

        public InputStream getAsciiStream() throws SQLException
        {
            throw new SQLException("ResultSet.getAsciiStream() not supported");
        }

        public InputStream getUnicodeStream() throws SQLException
        {
            throw new SQLException("ResultSet.getUnicodeStream() not supported");
        }

        public InputStream getBinaryStream() throws SQLException
        {
            if (_null = (_value == null)) return null;

            if (_value instanceof byte[]) return new ByteArrayInputStream((byte[])_value);

            if (_value instanceof Blob) return ((Blob)_value).getBinaryStream();

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public Reader getCharacterStream() throws SQLException
        {
            throw new SQLException("ResultSet.getCharacterStream() not supported");
        }

        public Ref getRef() throws SQLException
        {
            throw new SQLException("ResultSet.getRef() not supported");
        }

        public Blob getBlob() throws SQLException
        {
            if (_null = (_value == null)) return null;

            if (_value instanceof Blob) return (Blob)_value;

            if (_value instanceof byte[]) return Hibernate.createBlob((byte[])_value);

            throw new SQLException("Invalid type for column " + _name + " (" + _value.getClass() + ")");
        }

        public Clob getClob() throws SQLException
        {
            throw new SQLException("ResultSet.getClob() not supported");
        }

        public Array getArray() throws SQLException
        {
            throw new SQLException("ResultSet.getArray() not supported");
        }
    }
}
