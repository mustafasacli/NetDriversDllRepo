/*
 * Created on Feb 4, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.opensourceconnections.msjdbcproxy;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.cfg.Environment;
import org.hibernate.connection.ConnectionProvider;
import org.hibernate.connection.ConnectionProviderFactory;

/**
 * @author Eric Pugh
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class HibernateProvider implements ConnectionProvider
{
    private ConnectionProvider wrappedConnectionProvider = null;

    
    public void configure(Properties props) throws HibernateException {
        props.remove(Environment.CONNECTION_PROVIDER);
        wrappedConnectionProvider = ConnectionProviderFactory.newConnectionProvider(props);
        
    }
    
    public Connection getConnection() throws SQLException {
        
       return new ConnectionProxy(wrappedConnectionProvider.getConnection());
    }
    
    public void closeConnection(Connection conn) throws SQLException {
        
        wrappedConnectionProvider.closeConnection(conn);
    }
    
    protected void finalize() throws HibernateException{        
        close();
    }
    
    public void close() throws HibernateException{
        
        wrappedConnectionProvider.close();
        
    }

	public boolean supportsAggressiveRelease() {
		return wrappedConnectionProvider.supportsAggressiveRelease();
	}
    


   
}
