

package com.opensourceconnections.msjdbcproxy;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;

public class PreparedStatementProxy extends StatementProxy implements PreparedStatement
{
    public PreparedStatementProxy(ConnectionProxy connection, PreparedStatement statement)
    {
        super(connection, statement);
    }

    public ResultSet executeQuery() throws SQLException
    {
        return new ResultSetProxy(this, ((PreparedStatement)_statement).executeQuery());
    }

    public int executeUpdate() throws SQLException
    {
        return ((PreparedStatement)_statement).executeUpdate();
    }

    public void setNull(int parameterIndex, int sqlType) throws SQLException
    {
        ((PreparedStatement)_statement).setNull(parameterIndex, sqlType);
    }

    public void setBoolean(int parameterIndex, boolean x) throws SQLException
    {
        ((PreparedStatement)_statement).setBoolean(parameterIndex, x);
    }

    public void setByte(int parameterIndex, byte x) throws SQLException
    {
        ((PreparedStatement)_statement).setByte(parameterIndex, x);
    }

    public void setShort(int parameterIndex, short x) throws SQLException
    {
        ((PreparedStatement)_statement).setShort(parameterIndex, x);
    }

    public void setInt(int parameterIndex, int x) throws SQLException
    {
        ((PreparedStatement)_statement).setInt(parameterIndex, x);
    }

    public void setLong(int parameterIndex, long x) throws SQLException
    {
        ((PreparedStatement)_statement).setLong(parameterIndex, x);
    }

    public void setFloat(int parameterIndex, float x) throws SQLException
    {
        ((PreparedStatement)_statement).setFloat(parameterIndex, x);
    }

    public void setDouble(int parameterIndex, double x) throws SQLException
    {
        ((PreparedStatement)_statement).setDouble(parameterIndex, x);
    }

    public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException
    {
        ((PreparedStatement)_statement).setBigDecimal(parameterIndex, x);
    }

    public void setString(int parameterIndex, String x) throws SQLException
    {
        ((PreparedStatement)_statement).setString(parameterIndex, x);
    }

    public void setBytes(int parameterIndex, byte x[]) throws SQLException
    {
        ((PreparedStatement)_statement).setBytes(parameterIndex, x);
    }

    public void setDate(int parameterIndex, Date x) throws SQLException
    {
        ((PreparedStatement)_statement).setDate(parameterIndex, x);
    }

    public void setTime(int parameterIndex, Time x) throws SQLException
    {
        ((PreparedStatement)_statement).setTime(parameterIndex, x);
    }

    public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException
    {
        ((PreparedStatement)_statement).setTimestamp(parameterIndex, x);
    }

    public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException
    {
        ((PreparedStatement)_statement).setAsciiStream(parameterIndex, x, length);
    }

    public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException
    {
        ((PreparedStatement)_statement).setUnicodeStream(parameterIndex, x, length);
    }

    public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException
    {
        ((PreparedStatement)_statement).setBinaryStream(parameterIndex, x, length);
    }

    public void clearParameters() throws SQLException
    {
        ((PreparedStatement)_statement).clearParameters();
    }

    public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException
    {
        ((PreparedStatement)_statement).setObject(parameterIndex, x, targetSqlType, scale);
    }

    public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException
    {
        ((PreparedStatement)_statement).setObject(parameterIndex, x, targetSqlType);
    }

    public void setObject(int parameterIndex, Object x) throws SQLException
    {
        ((PreparedStatement)_statement).setObject(parameterIndex, x);
    }

    public boolean execute() throws SQLException
    {
        return ((PreparedStatement)_statement).execute();
    }

    public void addBatch() throws SQLException
    {
        ((PreparedStatement)_statement).addBatch();
    }

    public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException
    {
        ((PreparedStatement)_statement).setCharacterStream(parameterIndex, reader, length);
    }

    public void setRef(int i, Ref x) throws SQLException
    {
        ((PreparedStatement)_statement).setRef(i, x);
    }

    public void setBlob(int i, Blob x) throws SQLException
    {
        ((PreparedStatement)_statement).setBlob(i, x);
    }

    public void setClob(int i, Clob x) throws SQLException
    {
        ((PreparedStatement)_statement).setClob(i, x);
    }

    public void setArray(int i, Array x) throws SQLException
    {
        ((PreparedStatement)_statement).setArray(i, x);
    }

    public ResultSetMetaData getMetaData() throws SQLException
    {
        return ((PreparedStatement)_statement).getMetaData();
    }

    public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException
    {
        ((PreparedStatement)_statement).setDate(parameterIndex, x, cal);
    }

    public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException
    {
        ((PreparedStatement)_statement).setTime(parameterIndex, x, cal);
    }

    public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException
    {
        ((PreparedStatement)_statement).setTimestamp(parameterIndex, x, cal);
    }

    public void setNull(int paramIndex, int sqlType, String typeName) throws SQLException
    {
        ((PreparedStatement)_statement).setNull(paramIndex, sqlType, typeName);
    }

    public void setURL(int parameterIndex, URL x) throws SQLException
    {
        ((PreparedStatement)_statement).setURL(parameterIndex, x);
    }

    public ParameterMetaData getParameterMetaData() throws SQLException
    {
        return ((PreparedStatement)_statement).getParameterMetaData();
    }
}